let rat1 = document.querySelector("#rating1");
let rat2 = document.querySelector("#rating2");
let rat3 = document.querySelector("#rating3");
let rat4 = document.querySelector("#rating4");
let rat5 = document.querySelector("#rating5");

let zmianaKoloru1 = () => {
  let activeOrangeColor = document.querySelector(".orange");
  activeOrangeColor.classList.remove("orange");
  rat1.classList.add("orange");
};

let zmianaKoloru2 = () => {
  let activeOrangeColor = document.querySelector(".orange");
  activeOrangeColor.classList.remove("orange");
  rat2.classList.add("orange");
};

let zmianaKoloru3 = () => {
  let activeOrangeColor = document.querySelector(".orange");
  activeOrangeColor.classList.remove("orange");
  rat3.classList.add("orange");
};

let zmianaKoloru4 = () => {
  let activeOrangeColor = document.querySelector(".orange");
  activeOrangeColor.classList.remove("orange");
  rat4.classList.add("orange");
};

let zmianaKoloru5 = () => {
  let activeOrangeColor = document.querySelector(".orange");
  activeOrangeColor.classList.remove("orange");
  rat5.classList.add("orange");
};

rat1.addEventListener("click", zmianaKoloru1);
rat2.addEventListener("click", zmianaKoloru2);
rat3.addEventListener("click", zmianaKoloru3);
rat4.addEventListener("click", zmianaKoloru4);
rat5.addEventListener("click", zmianaKoloru5);
