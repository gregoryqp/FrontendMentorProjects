let rat1 = document.querySelector("#rating1");
let rat2 = document.querySelector("#rating2");
let rat3 = document.querySelector("#rating3");
let rat4 = document.querySelector("#rating4");
let rat5 = document.querySelector("#rating5");

let zmianaKoloru = () => {
  rat1.classList.toggle("orange");
  rat1.classList.remove(".rating:hover");
};

rat1.addEventListener("click", zmianaKoloru);
