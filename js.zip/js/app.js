// const now = new Date();
// const time = document.querySelector(".zegar");

// function zPrzoduZero(i) {
//   return `${i}`.padStart(2, "0");
// }
// console.log(zPrzoduZero(8));

// const displayOnPage = `

// Jest teraz godzina ${zPrzoduZero(now.getHours())}:${zPrzoduZero(
//   now.getMinutes()
// )}:${now.getSeconds()} <br>
// Dnia ${zPrzoduZero(now.getDate())}.${zPrzoduZero(
//   now.getMonth() + 1
// )}.${now.getFullYear()}
// `;

// time.innerHTML = displayOnPage;
// --------------------------------------------
// const time = document.querySelector(".zegar");

// function lz(i) {
//   return `${i}`.padStart(2, "0");
// }

// function showTextTime() {
//   const now = new Date();

//   const timeInWindow = `${lz(now.getHours())}:${lz(now.getMinutes())}:${lz(
//     now.getSeconds()
//   )}`;

//   time.innerHTML = timeInWindow;
//   window.requestAnimationFrame(showTextTime);
// }

// window.requestAnimationFrame(showTextTime);

// ------------------------------------------

// const element = document.querySelector("#test8");

// function lz(i) {
//   return `${i}`.padStart(2, "0");
// }

// //funkcja będzie przyjmować obiekt z danymi
// //zakładam, że nie wszystkie dane zostaną przekazane
// function calculateTimeDifference({
//   year,
//   month,
//   day,
//   hour = 0,
//   minutes = 0,
//   seconds = 0,
// }) {
//   const now = new Date();

//   //rok, miesiąc, dzień, godzina, minuta
//   const importantDate = new Date(year, month - 1, day, hour, minutes, seconds);
//   const msInADay = 24 * 60 * 60 * 1000; //1 dzień w milisekundach - to w nich przecież zwracany czas metodą getTime

//   //   console.log(importantDate);
//   const timeDifference = importantDate.getTime() - now.getTime();

//   const endTime = timeDifference < 0; //czy koniec odliczania

//   const eDaysToDate = timeDifference / msInADay;
//   const daysToDate = Math.floor(eDaysToDate);

//   //musimy tutaj sprawdzić, czy powyższa zmienna nie jest 0,
//   //bo inaczej poniżej byśmy mieli dzielenie przez 0
//   let daysToDateFix = daysToDate < 1 ? 1 : daysToDate;

//   const eHoursToDate = (eDaysToDate % daysToDateFix) * 24;
//   const hoursToDate = Math.floor(eHoursToDate);

//   const eMinutesToDate = (eHoursToDate - hoursToDate) * 60;
//   const minutesToDate = Math.floor(eMinutesToDate);

//   const eSecondsToDate = Math.floor((eMinutesToDate - minutesToDate) * 60);
//   const secondsToDate = Math.floor(eSecondsToDate);

//   return {
//     days: daysToDate,
//     hours: hoursToDate,
//     minutes: minutesToDate,
//     seconds: secondsToDate,
//     endTime,
//   };
// }

// //funkcja korzystając z powyższej funkcji pokaże na stronie odpowiedni tekst
// function showTimer(date) {
//   const dateParts = date.split("-");
//   if (dateParts.length === 1) return;

//   //zakładam że format daty to "2021-10-24-23-01". Ewentualnie można łatwo zmienić na inny
//   const [year, month, day, hour = 0, minutes = 0, seconds = 0] = dateParts;

//   //przekazuję do funkcji calculateTimeDifference powyższe dane
//   const timeDiff = calculateTimeDifference({
//     year,
//     month,
//     day,
//     hour,
//     minutes,
//     seconds,
//   });

//   {
//     //a następnie wyciągam z tego co zwraca odpowiednie rzeczy
//     const { days, hours, minutes, seconds, endTime } = timeDiff;

//     if (!endTime) {
//       element.innerHTML = `
//                 Do ważnej daty pozostało:
//                 <b>${days} dni
//                 ${hours} godzin
//                 ${minutes} minut i
//                 ${lz(seconds)} sekund</b>
//             `;

//       setTimeout(() => showTimer(date), 1000);
//     } else {
//       element.innerHTML = `Ważna data upłynęła`;
//     }
//   }
// }

// showTimer("2023-12-02");

let lata = document.querySelector(".year");
let miesiecy = document.querySelector(".mounth");
let dni = document.querySelector(".days");
let przycisk = document.querySelector(".przycisk");

let dzisiaj = new Date();
let dzienUrodzenia = new Date("Sep 16 1989");

let sekund = Math.abs(dzisiaj - dzienUrodzenia) / 1000;
// let minut = parseInt(sekund / 60);
// let godzin = parseInt(minut / 60);
// let dni = parseInt(godzin / 24);
let dniWSumie = parseInt(sekund / 60 / 60 / 24);
let lat = parseInt(dniWSumie / 365);
let mies = parseInt((dniWSumie % 365) / 30);
let resztaDni = (dniWSumie % 365) % 30;

let input = document.querySelector(".year");
let rok = input.value;

// console.log(lat + " lata");

// console.log(mies + " miesięcy");

// console.log(resztaDni + " dni");

// console.log(rok);

function pobierzRok() {
  dni.innerHTML = input.value;
  input.value = null;
}

przycisk.addEventListener("click", pobierzRok);
